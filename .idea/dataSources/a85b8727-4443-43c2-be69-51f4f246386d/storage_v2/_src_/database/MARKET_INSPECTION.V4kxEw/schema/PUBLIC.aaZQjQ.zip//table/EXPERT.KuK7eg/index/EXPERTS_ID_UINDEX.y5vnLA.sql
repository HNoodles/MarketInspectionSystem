create unique index EXPERTS_ID_UINDEX
    on EXPERT (ID);

